<!--hello.blade.php-->
<h2>Selamat Datang</h2>
<b>Semoga sukses dan lancar belajar Framework Laravel 10.x</b>